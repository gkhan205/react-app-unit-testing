import React from "react";
import { Provider } from "react-redux";
import { render, cleanup, fireEvent } from "@testing-library/react";
import user from "@testing-library/user-event";

import store from "store";
import { initialState } from "Todos/TodosReducer";

import AddTodo from "../";

const addTodo = jest.fn();

const renderWithRedux = () =>
  render(
    <Provider store={store}>
      <AddTodo onAdd={addTodo} />
    </Provider>
  );

describe("AddTodo Tests", () => {
  afterEach(cleanup);

  it("should test input value change", () => {
    const { getByTestId } = renderWithRedux();

    const input = getByTestId("add-todo-input");
    user.type(input, "New todo");
    expect(input).toHaveValue("New todo");
  });

  it("should test button click to add new todo", () => {
    const { getByTestId } = renderWithRedux();

    const button = getByTestId("add-todo-button");
    user.click(button);
    expect(addTodo).toHaveBeenCalled();
    expect(addTodo).toHaveBeenCalledTimes(1);

    const input = getByTestId("add-todo-input");
    expect(input).toHaveValue("");
  });

  it("should test todo form submit", () => {
    const { debug, getByTestId } = renderWithRedux();

    const form = getByTestId("add-todo-form");
    fireEvent.submit(form);

    expect(addTodo).toHaveBeenCalled();
    expect(addTodo).toHaveBeenCalledTimes(1);

    const input = getByTestId("add-todo-input");
    expect(input).toHaveValue("");

    debug();
  });
});
